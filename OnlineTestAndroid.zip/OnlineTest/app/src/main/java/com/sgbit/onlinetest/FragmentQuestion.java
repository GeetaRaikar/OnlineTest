package com.sgbit.onlinetest;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import com.sgbit.onlinetest.model.*;
import com.sgbit.onlinetest.util.HttpManager;
import com.sgbit.onlinetest.util.SessionManager;
import com.sgbit.onlinetest.util.Utility;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class FragmentQuestion extends Fragment {


    public FragmentQuestion() {
        // Required empty public constructor
    }

    ListView lvQuestion;

    int score = 0;
    View view;
    View v;
    User loggedInUser;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SessionManager sessionManager = new SessionManager(getContext());
        String userJson = sessionManager.getString("loggedInUser");
        System.out.println("userJson - " + userJson);

        Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'hh:mm:ss").create();
        loggedInUser = gson.fromJson(userJson, User.class);
        System.out.println("loggedInUser - " + loggedInUser);


    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.activity_fragment_question, container, false);
        ((ActivityHome) getActivity()).getSupportActionBar().setTitle("Question");
        lvQuestion = view.findViewById(R.id.lvUsers);

        RequestListTask requsetListTask = new RequestListTask();
        requsetListTask.execute();
        return view;
    }

    class RequestListTask extends AsyncTask<Void, Void, String> {
        SweetAlertDialog pDialog;

        @Override
        protected String doInBackground(Void... voids) {

            return new HttpManager().getData(getString(R.string.baseUrl) + "QuestionsServices/getAllQuestion");

        }

        @Override
        protected void onPreExecute() {
            pDialog = Utility.createSweetAlertDialog(getContext());
            pDialog.show();
        }

        @Override
        protected void onPostExecute(String s) {
            pDialog.dismiss();
            System.out.println("Result - " + s);

            if (s != null) {
                Gson gson = Utility.getGson();
                Type type = new TypeToken<List<Question>>() {
                }.getType();
                ArrayList<Question> questionList = gson.fromJson(s, type);
                System.out.println("QuestionList - " + questionList);
                QuestionAdaptor questionAdaptor = new QuestionAdaptor(getContext(), questionList);
                lvQuestion.setAdapter(questionAdaptor);
            }
        }
    }


    class QuestionAdaptor extends ArrayAdapter<Question> {

        Context context;
        ArrayList<Question> questionList;

        public QuestionAdaptor(@NonNull Context context, ArrayList<Question> questionList) {
            super(context, R.layout.row_question, questionList);
            this.context = context;
            this.questionList = questionList;
        }

        class ViewHolder {
            TextView tvQuestionNo, tvQuestion,tvAnswer1,tvAnswer2,tvAnswer3,tvAnswer4;
            EditText etselectedAnswer;
        }



        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            View row = convertView;

            ViewHolder holder = new ViewHolder();
            if (convertView == null) {
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                row = inflater.inflate(R.layout.row_question, parent, false);
                holder.tvQuestionNo = (TextView) row.findViewById(R.id.tvQuestionNo);
                holder.tvQuestion = (TextView) row.findViewById(R.id.tvQuestion);
                holder.tvAnswer1 = (TextView) row.findViewById(R.id.tvAnswer1);
                holder.tvAnswer2 = (TextView) row.findViewById(R.id.tvAnswer2);
                holder.tvAnswer3 = (TextView) row.findViewById(R.id.tvAnswer3);
                holder.tvAnswer4 = (TextView) row.findViewById(R.id.tvAnswer4);
                holder.etselectedAnswer = (EditText) row.findViewById(R.id.etselectedAnswer);

                row.setTag(holder);
            } else {
                holder = (ViewHolder) row.getTag();
            }

            Question selectedQuestion = questionList.get(position);


            final String selectedQuestionStr = Utility.getGson().toJson(selectedQuestion);
            holder.tvQuestionNo.setText("" + selectedQuestion.getqId());
            holder.tvQuestion.setText("" + selectedQuestion.getQuestion());

            holder.tvAnswer1.setText("" + selectedQuestion.getAnswer1());
            holder.tvAnswer2.setText("" + selectedQuestion.getAnswer2());
            holder.tvAnswer3.setText("" + selectedQuestion.getAnswer3());
            holder.tvAnswer4.setText("" + selectedQuestion.getAnswer4());


            return row;
        }


    }





}
