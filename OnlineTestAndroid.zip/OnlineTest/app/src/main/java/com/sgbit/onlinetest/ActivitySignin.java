package com.sgbit.onlinetest;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.sgbit.onlinetest.util.HttpManager;
import com.sgbit.onlinetest.util.SessionManager;
import com.sgbit.onlinetest.util.Utility;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class ActivitySignin extends AppCompatActivity {
        private TextView tvWel,tvFor,tvReg;
        private EditText etMobileno, etPass, etName;
        private Button bt2;
        String mobileNo;
        String password;
        final Context context=this;
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_signin);

            etMobileno = (EditText) findViewById(R.id.etMobileno);
            etPass = (EditText)findViewById(R.id.etPass);
            bt2 = (Button) findViewById(R.id.bt2);
            tvReg =(TextView) findViewById(R.id.tvReg);
            bt2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Boolean flag=true;
                    mobileNo = etMobileno.getText().toString();
                    password = etPass.getText().toString();


                    if(TextUtils.isEmpty(mobileNo)) {
                        etMobileno.setError("Enter the mobile number");
                        etMobileno.requestFocus();
                        flag = false;
                    }
                    if(TextUtils.isEmpty(password)){
                        etPass.setError("Invalid Password");
                        etPass.requestFocus();
                        flag = false;
                    }

                    if(flag){
                        LoginTask loginTask = new LoginTask();
                        loginTask.execute();
                    }
                }
            });
            tvReg.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    Intent intent=new Intent(context,ActivitySignup.class);
                    startActivity(intent);
                    finish();

                }
            });

        }
        class LoginTask extends AsyncTask<Void, Void, String> {
            SweetAlertDialog pDialog;

            @Override
            protected String doInBackground(Void... strings) {
                HttpManager httpManager = new HttpManager();
                String result = httpManager.getData(getString(R.string.baseUrl)+"UserServices/validateUser/"+mobileNo+"/"+password);
                return result;
            }
            @Override
            protected void onPreExecute() {
                pDialog = Utility.createSweetAlertDialog(ActivitySignin.this);
                pDialog.show();
            }

            @Override
            protected void onPostExecute(String result) {
                pDialog.dismiss();
                System.out.println("Result - " + result);
                if (result != null) {
                    SessionManager session = new SessionManager(getApplicationContext());
                    session.putString("loggedInUser",result);
                    Intent intent = new Intent(ActivitySignin.this, ActivityHome.class);
                    startActivity(intent);
                    finish();

                } else {
                    Toast.makeText(getApplicationContext(),"Invalid Credentials",Toast.LENGTH_LONG).show();
                }

            }
        }
    }
