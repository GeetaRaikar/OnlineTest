package com.sgbit.onlinetest;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.gson.Gson;

import com.sgbit.onlinetest.util.HttpManager;
import com.sgbit.onlinetest.util.Utility;

import com.sgbit.onlinetest.model.User;

import cn.pedant.SweetAlert.SweetAlertDialog;


public class ActivitySignup extends AppCompatActivity {

    private EditText etFirstName,etLastName, etPhone,etPassword,etConfirmPassword;
    private Button btSubmit;

    Gson gson;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        gson = Utility.getGson();
        etFirstName =(EditText) findViewById(R.id.etFirstName);
        etLastName =(EditText) findViewById(R.id.etLastName);
        etPassword =(EditText) findViewById(R.id.etPassword);
        etPhone =(EditText) findViewById(R.id.etPhone);
        etConfirmPassword = (EditText) findViewById(R.id.etConfirmPassword);

        btSubmit = (Button) findViewById(R.id.btSubmit);



        btSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String firstName = etFirstName.getText().toString();
                if(TextUtils.isEmpty(firstName)){
                    etFirstName.setError("Please Enter the name");
                    etFirstName.requestFocus();
                    return;
                }
                String lastName = etLastName.getText().toString();
                if(TextUtils.isEmpty(lastName)){
                    etLastName.setError("Please Enter the name");
                    etLastName.requestFocus();
                    return;
                }

                String phone = etPhone.getText().toString();
                if(!Utility.isPasswordValid(phone)){
                    etPhone.setError("Please Enter the valid Phone Number");
                    etPhone.requestFocus();
                    return;
                }

                String password = etPassword.getText().toString();
                if(TextUtils.isEmpty(password)){
                    etPassword.setError("Please Enter the Password");
                    etPassword.requestFocus();
                    return;
                }
                String confirmPassword = etConfirmPassword.getText().toString();
                if(!confirmPassword.equals(password)){
                    etConfirmPassword.setError("Mismatch in password");
                    etConfirmPassword.requestFocus();
                    return;
                }


                User user = new User();
                user.setStatus("I");
                user.setFirstName(firstName);
                user.setLastName(lastName);
                user.setMobileNo(phone);
                user.setPassword(password);
                String userJson = gson.toJson(user);

                System.out.println("userJson=" + userJson);

                RegistrationTask registrationTask = new RegistrationTask();

                registrationTask.execute(userJson);
            }


        });


    }

    class RegistrationTask extends AsyncTask<String, Void,String> {

        SweetAlertDialog pDialog;
        @Override
        protected void onPreExecute() {
            pDialog = Utility.createSweetAlertDialog(ActivitySignup.this);
            if(pDialog!=null){
                pDialog.show();
            }
        }
        @Override
        protected String doInBackground(String... strings) {
            String userJson = strings[0];
            HttpManager httpManager = new HttpManager();
            String result = httpManager.postData(getString(R.string.baseUrl)+"UserServices/addUser",userJson);
            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            if(pDialog!=null){
                pDialog.dismiss();
            }
            System.out.println("Result - "+result);
            if(result.equals("1")){
                Intent intent =new Intent(ActivitySignup.this, ActivitySignin.class);
                startActivity(intent);
                finish();

            }
            else{

            }
        }
    }
}