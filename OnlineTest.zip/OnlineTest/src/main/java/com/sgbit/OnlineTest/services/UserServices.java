package com.sgbit.OnlineTest.services;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;


import com.sgbit.OnlineTest.dao.UserDAO;
import com.sgbit.OnlineTest.model.User;

@Path("UserServices")
public class UserServices {
	UserDAO userdao=new UserDAO();

	@GET 
	@Produces(MediaType.TEXT_PLAIN)
	public String getIt() {
		return "Got it!";
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("addUser")
	public int addUser(User user) {
		return userdao.addUser(user);
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("updateUser")
	public int updateUser(User user) 
	{
		return userdao.updateUser(user);

	}   

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("deleteUser")
	public int deleteUser(User user) 
	{
		return userdao.deleteUser(user);

	}
  
	@GET
	@Path("validateUser/{mobileNo}/{password}")
	@Produces(MediaType.APPLICATION_JSON)
	public User validateCustomer(@PathParam("mobileNo")  String mobileNo,@PathParam("password") String password) {

		return userdao.validateUser(mobileNo,password);
	}
	
}
