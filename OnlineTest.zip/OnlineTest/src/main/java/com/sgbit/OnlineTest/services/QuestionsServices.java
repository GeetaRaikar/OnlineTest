package com.sgbit.OnlineTest.services;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.sgbit.OnlineTest.dao.QuestionsDAO;
import com.sgbit.OnlineTest.model.Questions;

@Path("QuestionsServices")
public class QuestionsServices {
	QuestionsDAO questionsdao=new QuestionsDAO();

	@GET 
	@Produces(MediaType.TEXT_PLAIN)
	public String getIt() {
		return "Got it!";
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("addQuestion")
	public int addQuestion(Questions question) {
		return questionsdao.addQuestion(question);
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("updateQuestion")
	public int updateQuestion(Questions question) 
	{
		return questionsdao.updateQuestion(question);

	}   

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("deleteQuestion")
	public int deleteQuestion(Questions question) 
	{
		return questionsdao.deleteQuestion(question);

	}

	@GET
	@Path("getAllQuestion")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Questions> getAllQuestion() {

		return questionsdao.getAllQuestion();
	}
	
	@GET
	@Path("/availableQuestion/{qId}")
	@Produces(MediaType.APPLICATION_JSON) 
	public Questions availableQuestion(@PathParam("qId") int qId) {
		return questionsdao.availableQuestion(qId);
	}


}
