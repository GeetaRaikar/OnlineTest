package com.sgbit.OnlineTest.dao;
import java.util.List;

import org.hibernate.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.sgbit.OnlineTest.model.Questions;

public class QuestionsDAO {
	public  int addQuestion(Questions question) {
		SessionFactory sessionfactory=null;
		Session session=null;
		try
		{
			sessionfactory=new Configuration().configure().buildSessionFactory();
			session=sessionfactory.openSession();
			Transaction transaction=session.beginTransaction();
			session.save(question);
			transaction.commit();
			return 1;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(sessionfactory!=null) {
				sessionfactory.close();
			}
			if(session!=null) {
				session.close();
			}

		}
		return 0;

	}


	public  int updateQuestion(Questions question) {
		
		SessionFactory sessionfactory=null;
		Session session=null;
		try
		{   
			sessionfactory=new Configuration().configure().buildSessionFactory();
			session=sessionfactory.openSession();
			Transaction transaction=session.beginTransaction();
			session.update(question);
			transaction.commit();
			return 1;
		}
		catch(Exception e) {
			e.printStackTrace();
		}		
		finally {
			if(sessionfactory!=null) {
				sessionfactory.close();
			}
			if(session!=null) {
				session.close();
			}

		}
		return 0;	
	}
	public  int deleteQuestion(Questions question) {
		SessionFactory sessionFactory = null;
		Session session = null;
		try {
			sessionFactory = new Configuration().configure().buildSessionFactory();
			session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			session.delete(question);
			transaction.commit();
			return 1;
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			if(sessionFactory != null) {
				sessionFactory.close();
			}
			if(session !=null) {
				session.close();
			}
		}

		return 0;
	}

	public static List<Questions> getAllQuestion()  {
		List<Questions> questionsList=null;
		SessionFactory sessionfactory=null;
		Session session=null;
		Transaction transaction=null;
		try {
			sessionfactory = new Configuration().configure()
					.buildSessionFactory();
			session = sessionfactory.openSession();
			transaction=session.beginTransaction();
			Query query= session.createQuery("from Questions");
			questionsList= query.list();
			//System.out.println("questionsList");
			transaction.commit();

		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error :" + e.getMessage());

		}
		finally {
			if(session != null) {
				session.close();
			}
			if(sessionfactory != null) {
				sessionfactory.close();
			}
		}
		return questionsList;
	}
	public Questions availableQuestion(int qId) {
		System.out.println(qId);
		SessionFactory sessionFactory=null;
		Session session=null;
		int i;
		
		List<Questions> questionList=null;
		
		Transaction transaction=null;
		try {

			sessionFactory=new Configuration().configure().buildSessionFactory();
			session=sessionFactory.openSession();
			transaction = session.beginTransaction();

			Query query=session.createQuery("from  Questions where qId =:qId");
			query.setParameter("qId", qId);
			
			questionList=query.list();
			//System.out.println(requestList);
			transaction.commit();
			if(questionList != null && questionList.size()>0) {
				return questionList.get(0);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			if(transaction != null) {
				transaction.rollback();
			}
		}
		finally {
			if(sessionFactory != null) {
				sessionFactory.close();
			}
			if(session != null) {
				session.close();
			}
		}
		// System.out.println("No Pharmacy");
		return null;

	}

}
