package com.sgbit.OnlineTest.dao;

import java.util.List;
import org.hibernate.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.sgbit.OnlineTest.model.User;

public class UserDAO {
	public  int addUser(User user) {
		SessionFactory sessionfactory=null;
		Session session=null;
		try
		{
			sessionfactory=new Configuration().configure().buildSessionFactory();
			session=sessionfactory.openSession();
			Transaction transaction=session.beginTransaction();
			session.save(user);
			transaction.commit();
			return 1;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(sessionfactory!=null) {
				sessionfactory.close();
			}
			if(session!=null) {
				session.close();
			}

		}
		return 0;

	}


	public  int updateUser(User user) {
		
		SessionFactory sessionfactory=null;
		Session session=null;
		try
		{   
			sessionfactory=new Configuration().configure().buildSessionFactory();
			session=sessionfactory.openSession();
			Transaction transaction=session.beginTransaction();
			session.update(user);
			transaction.commit();
			return 1;
		}
		catch(Exception e) {
			e.printStackTrace();
		}		
		finally {
			if(sessionfactory!=null) {
				sessionfactory.close();
			}
			if(session!=null) {
				session.close();
			}

		}
		return 0;	
	}
	public  int deleteUser(User user) {
		SessionFactory sessionFactory = null;
		Session session = null;
		try {
			sessionFactory = new Configuration().configure().buildSessionFactory();
			session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			session.delete(user);
			transaction.commit();
			return 1;
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			if(sessionFactory != null) {
				sessionFactory.close();
			}
			if(session !=null) {
				session.close();
			}
		}

		return 0;
	}
	public User validateUser(String mobileNo,String password ){
		SessionFactory sessionFactory = null;
		Session session=null;
		List<User> userList=null;
		try {
			sessionFactory=new Configuration().configure().buildSessionFactory();
			session=sessionFactory.openSession();
			Transaction transaction=session.beginTransaction();

			Query query = session.createQuery("from User where mobileNo = :mobileNo and password =: password ");
			query.setParameter("mobileNo", mobileNo);
			query.setParameter("password", password);

			userList = query.list();

			transaction.commit();
			if(userList!=null & userList.size()>0) {
				return userList.get(0);
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if( sessionFactory != null) {
				sessionFactory.close();
			}
			if(session != null) {
				session.close();

			}
		}
		return null;

	}
}
